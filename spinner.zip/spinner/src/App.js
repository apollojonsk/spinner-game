import './App.css';
import { useState, useEffect } from 'react';
import storage from './firebase/firebaseConfig';
import { ref, uploadBytesResumable } from "firebase/storage";

function App({ cardimage }) {
  const [rotation, setRotation] = useState(0);
  const [file, setFile] = useState("");
  

  // Handle file upload event and update state
  const handleChange = (event) => {
    setFile(event.target.files[0]);
  }

  const handleUpload = () => {
    if (!file) {
      alert("Please upload an image first!");
    }

    const storageRef = ref(storage, `/files/${file.name}`);

    // progress can be paused and resumed. It also exposes progress updates.
    // Receives the storage reference and the file to upload.
    uploadBytesResumable(storageRef, file);

    //const uploadTask = uploadBytesResumable(storageRef, file);

    // uploadTask.on(
    //   "state_changed",
    //   (snapshot) => {
    //     const percent = Math.round(
    //       (snapshot.bytesTransferred / snapshot.totalBytes) * 100
    //     );
    //   },
    //   (err) => console.log(err),
    // );
  }
  
  useEffect(() => {

  }, [])

  return (
    <div style={{
      backgroundImage: `url("${cardimage}")`,
      backgroundSize: `250px 250px`,
      backgroundRepeat: `no-repeat`,
      display: `flex`,
      height:'250px',
      width:'250px',
      justifyContent: `center`,
      borderRadius: `125px`,
      border: `6px solid white`,
    }}>
      <img src="https://firebasestorage.googleapis.com/v0/b/spinnergame-da761.appspot.com/o/imgpsh_fullsize_anim.png?alt=media&token=19d87720-3ab5-49f9-a665-f867bd7fd33e"
        style={{
          transform: `rotate(${rotation}deg)`,
          
          transition: 'transform 5000ms ease',
          alignSelf: `center`
        }}
        height="200"
        onClick={() => { setRotation(rotation + Math.random() * 3600) }}
      ></img>
      {/* <input type="file" onChange={handleChange} accept="/image/*" />
      <button onClick={handleUpload}>Upload Card</button> */}
    </div>

  )
}

export default App;
