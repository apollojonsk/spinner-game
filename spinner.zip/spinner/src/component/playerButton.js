import Button from '@material-ui/core/Button';
import { useState } from 'react';

const PlayerButton = ({x,y}) => {

    const [on, setOn] = useState(false);

    const changeOn = () => {
        console.log("jere");
        setOn(!on);
    }

    return (
            <Button style={{
                position: `absolute`,
                top: `${x}px`,
                left: `${y}px`,
            }}
                variant={on ? ("contained") : ("outlined")} size="large" color="primary" onClick={() => { changeOn(); }}>
                P
            </Button>            
    )
}

export default PlayerButton;