import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC4DYDxfB9lAN8UsOM1g9DW6hJhTgo0v1o",
  authDomain: "spinnergame-da761.firebaseapp.com",
  projectId: "spinnergame-da761",
  storageBucket: "spinnergame-da761.appspot.com",
  messagingSenderId: "268799121948",
  appId: "1:268799121948:web:51cf4edd269315217d5dd9",
  measurementId: "G-TRENFBLNT6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

export default storage;