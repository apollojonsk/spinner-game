import './App.css';
import { useState, useEffect } from 'react';

import { ListBox } from 'primereact/listbox';

import storage from './firebase/firebaseConfig';
import { ref, getDownloadURL, listAll } from "firebase/storage";

import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';

import App from './App';
import PlayerButton from './component/playerButton';

function Back() {

  const [teams, setTeams] = useState([]);

  const [team1, setTeam1] = useState(0);
  const [team2, setTeam2] = useState(0);

  const [team1card, setTeam1card] = useState([]);
  const [team2card, setTeam2card] = useState([]);

  const [team1cname, setTeam1cname] = useState(0);
  const [team2cname, setTeam2cname] = useState(0);

  const [url1, setUrl1] = useState(0);
  const [url2, setUrl2] = useState(0);

  const changeteam1 = async () => {
    if (team1 && team1cname) {
      const storageRef = ref(storage, `/team_data/${team1}/${team1cname}`);
      const url = await getDownloadURL(storageRef);
      setUrl1(url);
      console.log(url);
    }
  }

  const changeteam2 = async () => {
    if (team2 && team2cname) {
      const storageRef = ref(storage, `/team_data/${team2}/${team2cname}`);
      const url = await getDownloadURL(storageRef);
      setUrl2(url);
    }
  }

  useEffect(() => {
    changeteam1();
  }, [team1cname])

  useEffect(() => {
    changeteam2();
  }, [team2cname])

  useEffect(() => {
    const storageRef = ref(storage, `/team_data/` + team1);
    listAll(storageRef)
      .then(async res => {
        const data = res.items.map(item => item.name);
        setTeam1card(data);
      })
      .catch(err => {
        alert(err.message);
      })
  }, [team1])

  useEffect(() => {
    const storageRef = ref(storage, `/team_data/` + team2);
    listAll(storageRef)
      .then(async res => {
        const data = res.items.map(item => item.name);
        setTeam2card(data);
      })
      .catch(err => {
        alert(err.message);
      })
  }, [team2])

  const getTeams = () => {
    const storageRef = ref(storage, `/team_data/`);
    listAll(storageRef)
      .then(res => {
        const data = res.prefixes.map(item => item.name);
        setTeams(data);
      })
  }

  useEffect(() => {
    getTeams();
  }, [])

  return (
    <div style={{ display: `flex` }}>
      <div style={{
        backgroundImage: `url("https://firebasestorage.googleapis.com/v0/b/spinnergame-da761.appspot.com/o/back.png?alt=media&token=86437dea-4c68-477d-90da-58ebfe15d626")`,
        backgroundSize: `1200px 768px`,
        backgroundRepeat: `no-repeat`,
        width: `1200px`,
        height: `768px`,
        display: `flex`,
        justifyContent: `end`,
        flexDirection: `column`,
      }}>
        <div style={{
          display: `flex`,
          justifyContent: `space-between`,
          paddingBottom: `15px`,
        }}>
          <div style={{
            flexDirection: `column`,
            display: `flex`,
            justifyContent: `space-around`,
            height: `140px`,
            background: `white`,
            borderRadius: `20px`,
          }}>
            <Autocomplete
              value={team1}
              onChange={(event, newValue) => {
                setTeam1(newValue);
              }}
              options={teams}
              style={{ width: 200 }}
              renderInput={(params) =>
                <TextField {...params} label="Home" variant="outlined" />}
            />
            <Autocomplete
              value={team1cname}
              onChange={(event, newValue) => {
                setTeam1cname(newValue);
              }}
              options={team1card}
              style={{ width: 200 }}
              renderInput={(params) =>
                <TextField {...params} label="Home Player" variant="outlined" />}
            />
          </div>
          <div style={{
            flexDirection: `column`,
            display: `flex`,
            justifyContent: `space-around`,
            height: `140px`,
            background: `white`,
            borderRadius: `20px`,
          }}>
            <Autocomplete
              value={team2}
              onChange={(event, newValue) => {
                setTeam2(newValue);
              }}
              options={teams}
              style={{ width: 200 }}
              renderInput={(params) =>
                <TextField {...params} label="Away" variant="outlined" />}
            />
            <Autocomplete
              value={team2cname}
              onChange={(event, newValue) => {
                setTeam2cname(newValue);
              }}
              options={team2card}
              style={{ width: 200 }}
              renderInput={(params) =>
                <TextField {...params} label="Away Player" variant="outlined" />}
            />
          </div>
        </div>
        <div style={{
          display: `flex`,
          justifyContent: `space-around`
        }}>
          <App cardimage={url1} />
          <App cardimage={url2} />
        </div>
      </div>      
      <PlayerButton x={442} y={357}/>
      <PlayerButton x={442} y={809}/>
      <PlayerButton x={397} y={585}/>
      <PlayerButton x={521} y={585}/>
    </div>
  )
}

export default Back;
